//
//  CircleImage.swift
//  FirstSwiftProject
//
//  Created by Salman on 27/04/18.
//  Copyright © 2018 Salman. All rights reserved.
//

import UIKit

class CircleImage: UIViewController {
    
    
   @IBOutlet weak var circleIMAGE: UIImageView!
    
   @IBOutlet weak var profileImageView: UIImageView!
    
    @IBOutlet weak var circlimage3: UIImageView!
  
    @IBOutlet weak var circleImage4: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.profileImageView.layer.cornerRadius = self.profileImageView.frame.size.width / 2;
        self.profileImageView.clipsToBounds = true;
        
        self.circleIMAGE.layer.cornerRadius = self.profileImageView.frame.size.width / 2;
        self.circleIMAGE.clipsToBounds = true;
        
        self.circlimage3.layer.cornerRadius = self.profileImageView.frame.size.width / 2;
        self.circlimage3.clipsToBounds = true;
        
        self.circleImage4.layer.cornerRadius = self.profileImageView.frame.size.width / 2;
        self.circleImage4.clipsToBounds = true;
     
  
        
//        self.profileImageView.layer.borderWidth = 3.0;
        
        
          }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
